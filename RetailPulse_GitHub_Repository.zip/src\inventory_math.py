import pandas as pd
import numpy as np
from datetime import datetime

class InventoryOptimizationEngine:
    """
    Pure Operations Research & Statistical Inventory Optimization Engine.
    Implements Safety Stock (SS), Reorder Point (ROP), Economic Order Quantity (EOQ),
    ABC-XYZ Matrix classification, Stockout Risk categorization, and automated PO Generation.
    """
    def __init__(self, tx_df, inventory_df=None):
        self.tx_df = tx_df
        self.inventory_df = inventory_df

    def compute_inventory_parameters(self, service_level=0.95, target_date=None):
        """
        Calculates ROP, SS, EOQ, ABC-XYZ, and Restock Requirements for all SKUs.
        """
        if self.tx_df is None or self.tx_df.empty:
            return pd.DataFrame()

        df = self.tx_df.copy()
        all_dates = sorted(df["date_str"].unique())
        latest_date = target_date if (target_date and target_date in all_dates) else all_dates[-1]

        # Filter up to target date
        hist_df = df[df["date_str"] <= latest_date]

        # Calculate daily demand distribution per SKU
        daily_demand = hist_df.groupby(["sku_id", "date_str"])["quantity"].sum().reset_index()

        # Calculate total revenue per SKU for ABC classification
        sku_rev = hist_df.groupby("sku_id")["total_amount"].sum().reset_index()
        total_store_rev = sku_rev["total_amount"].sum()
        sku_rev = sku_rev.sort_values("total_amount", ascending=False).reset_index(drop=True)
        sku_rev["cum_rev"] = sku_rev["total_amount"].cumsum()
        sku_rev["cum_pct"] = (sku_rev["cum_rev"] / total_store_rev) * 100.0

        # Assign ABC Category
        def get_abc(pct):
            if pct <= 80.0:
                return "A"
            elif pct <= 95.0:
                return "B"
            else:
                return "C"

        sku_rev["abc_class"] = sku_rev["cum_pct"].apply(get_abc)
        abc_map = dict(zip(sku_rev["sku_id"], sku_rev["abc_class"]))

        # Z-score for service level (Standard Normal Inverse CDF)
        # 90% -> 1.28, 95% -> 1.645, 99% -> 2.33
        if service_level >= 0.99:
            z_val = 2.326
        elif service_level >= 0.95:
            z_val = 1.645
        elif service_level >= 0.90:
            z_val = 1.282
        else:
            z_val = 1.0

        # Unique SKU metadata
        sku_meta = df[["sku_id", "product_name", "category", "unit_price"]].drop_duplicates(subset=["sku_id"])

        # Inventory lookup
        inv_dict = {}
        if self.inventory_df is not None and not self.inventory_df.empty:
            for _, r in self.inventory_df.iterrows():
                inv_dict[r["sku_id"]] = r

        results = []
        for _, s_row in sku_meta.iterrows():
            sku = s_row["sku_id"]
            pname = s_row["product_name"]
            cat = s_row["category"]
            price = s_row["unit_price"]

            sku_daily = daily_demand[daily_demand["sku_id"] == sku]["quantity"]
            
            # Demand statistics
            if len(sku_daily) > 0:
                mean_d = float(sku_daily.mean())
                std_d = float(sku_daily.std(ddof=1)) if len(sku_daily) > 1 else 0.5
                if np.isnan(std_d) or std_d <= 0:
                    std_d = 0.5
            else:
                mean_d = 1.0
                std_d = 0.5

            # XYZ Classification via Coefficient of Variation (CV = sigma / mu)
            cv = std_d / mean_d if mean_d > 0 else 1.5
            if cv <= 0.5:
                xyz_class = "X (Stable)"
            elif cv <= 1.0:
                xyz_class = "Y (Fluctuating)"
            else:
                xyz_class = "Z (Erratic)"

            abc_class = abc_map.get(sku, "B")
            abc_xyz_matrix = f"{abc_class}-{xyz_class[0]}"

            # Inventory Master attributes
            inv_info = inv_dict.get(sku, None)
            if inv_info is not None:
                current_stock = int(inv_info["current_stock"])
                lead_time = int(inv_info["lead_time_days"])
                unit_cost = float(inv_info["unit_cost"])
                order_fixed_cost = float(inv_info["order_fixed_cost"])
                annual_holding_cost = float(inv_info["annual_holding_cost"])
                min_batch = int(inv_info["min_order_batch"])
                supplier = str(inv_info["supplier"])
            else:
                # Default heuristics if not in master
                current_stock = int(mean_d * 2.0)
                lead_time = 3
                unit_cost = round(price * 0.80, 2)
                order_fixed_cost = 350.0
                annual_holding_cost = round(unit_cost * 0.18, 2)
                min_batch = 10
                supplier = "Direct Distributor"

            # 1. Safety Stock (SS) Calculation
            # SS = Z * sigma_d * sqrt(LeadTime)
            safety_stock = int(np.ceil(z_val * std_d * np.sqrt(lead_time)))

            # 2. Reorder Point (ROP) Calculation
            # ROP = (Mean Demand * Lead Time) + Safety Stock
            lead_time_demand = mean_d * lead_time
            rop = int(np.ceil(lead_time_demand + safety_stock))

            # 3. Economic Order Quantity (EOQ) Calculation
            # Annual Demand D = mean_d * 365
            annual_demand = mean_d * 365.0
            if annual_holding_cost > 0:
                raw_eoq = np.sqrt((2.0 * annual_demand * order_fixed_cost) / annual_holding_cost)
                eoq = int(np.ceil(max(raw_eoq, min_batch)))
            else:
                eoq = int(min_batch)

            # 4. Stockout Runway (Days of Supply left on shelf)
            runway_days = round(current_stock / mean_d, 1) if mean_d > 0 else 999.0

            # 5. Stock Status & Urgency Classification
            if current_stock <= safety_stock or runway_days < 1.0:
                urgency = "CRITICAL (Stockout Imminent)"
                urgency_badge = "critical"
                needs_reorder = True
            elif current_stock <= rop:
                urgency = "WARNING (Reorder Now)"
                urgency_badge = "warning"
                needs_reorder = True
            elif current_stock > (rop + 2 * eoq):
                urgency = "OVERSTOCKED"
                urgency_badge = "overstocked"
                needs_reorder = False
            else:
                urgency = "HEALTHY"
                urgency_badge = "healthy"
                needs_reorder = False

            # 6. Suggested Reorder Quantity
            if needs_reorder:
                # Target stock level = ROP + EOQ
                deficit = (rop + eoq) - current_stock
                suggested_order_qty = int(np.ceil(max(deficit, eoq) / min_batch) * min_batch)
            else:
                suggested_order_qty = 0

            estimated_po_cost = round(suggested_order_qty * unit_cost, 2)

            results.append({
                "sku_id": sku,
                "product_name": pname,
                "category": cat,
                "current_stock": current_stock,
                "avg_daily_demand": round(mean_d, 1),
                "demand_std_dev": round(std_d, 2),
                "cv_score": round(cv, 2),
                "lead_time_days": lead_time,
                "safety_stock": safety_stock,
                "reorder_point_rop": rop,
                "economic_order_qty_eoq": eoq,
                "runway_days": runway_days,
                "stock_urgency": urgency,
                "urgency_badge": urgency_badge,
                "needs_reorder": needs_reorder,
                "suggested_order_qty": suggested_order_qty,
                "unit_cost": unit_cost,
                "selling_price": price,
                "margin_pct": round(((price - unit_cost) / price) * 100.0, 1) if price > 0 else 0.0,
                "estimated_po_cost": estimated_po_cost,
                "supplier": supplier,
                "abc_class": abc_class,
                "xyz_class": xyz_class,
                "abc_xyz_segment": abc_xyz_matrix
            })

        res_df = pd.DataFrame(results)
        # Sort so that CRITICAL items appear at the very top, followed by WARNING
        sort_rank = {
            "CRITICAL (Stockout Imminent)": 1,
            "WARNING (Reorder Now)": 2,
            "HEALTHY": 3,
            "OVERSTOCKED": 4
        }
        res_df["rank"] = res_df["stock_urgency"].map(sort_rank)
        res_df = res_df.sort_values(by=["rank", "runway_days"]).drop(columns=["rank"]).reset_index(drop=True)
        return res_df

    def generate_purchase_order_df(self, inventory_params_df):
        """
        Filters out SKUs that require restocking and formats a production-ready Purchase Order (PO).
        """
        if inventory_params_df is None or inventory_params_df.empty:
            return pd.DataFrame()

        po_items = inventory_params_df[inventory_params_df["needs_reorder"] == True].copy()
        if po_items.empty:
            return pd.DataFrame()

        po_df = po_items[[
            "sku_id", "product_name", "category", "supplier", "current_stock",
            "safety_stock", "reorder_point_rop", "suggested_order_qty",
            "unit_cost", "estimated_po_cost", "stock_urgency"
        ]].copy()

        po_df = po_df.rename(columns={
            "sku_id": "SKU Code",
            "product_name": "Product Description",
            "category": "Department",
            "supplier": "Vendor / Supplier",
            "current_stock": "Current Shelf Stock",
            "safety_stock": "Safety Stock (SS)",
            "reorder_point_rop": "Reorder Point (ROP)",
            "suggested_order_qty": "Order Quantity",
            "unit_cost": "Unit Cost (INR)",
            "estimated_po_cost": "Total Estimated Cost (INR)",
            "stock_urgency": "Restock Urgency"
        })

        return po_df
