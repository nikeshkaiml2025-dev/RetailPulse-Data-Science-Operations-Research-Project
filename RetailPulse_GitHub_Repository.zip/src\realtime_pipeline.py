import random
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

class RealtimeDataPipeline:
    """
    Real-Time Data Preprocessing, ETL, and Stream Ingestion Pipeline.
    Validates, cleans, transforms POS transactions and atomically updates
    the SQL database and inventory stock levels.
    """
    def __init__(self, db):
        self.db = db
        self.catalog_cache = {}
        self.refresh_catalog_cache()

    def refresh_catalog_cache(self):
        catalog_df = self.db.get_catalog_df()
        for _, r in catalog_df.iterrows():
            self.catalog_cache[r["sku_id"]] = {
                "sku_id": r["sku_id"],
                "product_name": r["product_name"],
                "category": r["category"],
                "selling_price": float(r["selling_price"]),
                "cost_price": float(r["cost_price"]),
                "supplier": r["supplier"]
            }

    def preprocess_raw_transaction(self, raw_record):
        """
        Validates, cleans, and engineers features for a single raw transaction record.
        """
        # 1. Validation of SKU
        sku = str(raw_record.get("sku_id", "")).strip()
        if not sku or sku not in self.catalog_cache:
            # Fallback check for product_name lookup
            pname = raw_record.get("product_name", "")
            found = False
            for k, v in self.catalog_cache.items():
                if v["product_name"].lower() == pname.lower():
                    sku = k
                    found = True
                    break
            if not found:
                raise ValueError(f"Unknown SKU code or product: {sku} / {pname}")

        meta = self.catalog_cache[sku]

        # 2. Type casting & Cleaning
        try:
            qty = int(raw_record.get("quantity", 1))
            if qty <= 0:
                qty = 1
        except (ValueError, TypeError):
            qty = 1

        unit_price = float(raw_record.get("unit_price", meta["selling_price"]))
        if unit_price <= 0:
            unit_price = meta["selling_price"]

        total_amount = round(qty * unit_price, 2)

        # 3. Timestamp parsing & Temporal Feature Engineering
        raw_ts = raw_record.get("timestamp")
        if raw_ts:
            try:
                dt = pd.to_datetime(raw_ts)
            except Exception:
                dt = datetime.now()
        else:
            dt = datetime.now()

        tx_id = str(raw_record.get("transaction_id", f"TXN-RT-{random.randint(100000, 999999)}"))
        cust_id = str(raw_record.get("customer_id", f"CUST-{random.randint(1000, 1450)}"))
        pay_method = str(raw_record.get("payment_method", "UPI / QR"))

        # Cleaned Record
        clean_item = {
            "transaction_id": tx_id,
            "timestamp": dt.strftime("%Y-%m-%d %H:%M:%S"),
            "date_str": dt.strftime("%Y-%m-%d"),
            "hour": int(dt.hour),
            "day_name": dt.strftime("%A"),
            "is_weekend": 1 if dt.weekday() >= 5 else 0,
            "customer_id": cust_id,
            "sku_id": sku,
            "product_name": meta["product_name"],
            "category": meta["category"],
            "quantity": qty,
            "unit_price": unit_price,
            "total_amount": total_amount,
            "payment_method": pay_method
        }
        return clean_item

    def ingest_realtime_records(self, raw_records):
        """
        Preprocesses and atomically writes transactions to SQLite,
        and decrements inventory on-hand stock.
        """
        if isinstance(raw_records, dict):
            raw_records = [raw_records]

        cleaned_records = []
        alerts = []

        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            for r in raw_records:
                try:
                    clean_r = self.preprocess_raw_transaction(r)
                    cleaned_records.append(clean_r)

                    # Insert transaction into SQL
                    cursor.execute("""
                    INSERT INTO pos_transactions (
                        transaction_id, timestamp, date_str, hour, day_name,
                        is_weekend, customer_id, sku_id, product_name, category,
                        quantity, unit_price, total_amount, payment_method
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
                    """, (
                        clean_r["transaction_id"], clean_r["timestamp"], clean_r["date_str"],
                        clean_r["hour"], clean_r["day_name"], clean_r["is_weekend"],
                        clean_r["customer_id"], clean_r["sku_id"], clean_r["product_name"],
                        clean_r["category"], clean_r["quantity"], clean_r["unit_price"],
                        clean_r["total_amount"], clean_r["payment_method"]
                    ))

                    # Atomically update inventory on-hand stock
                    cursor.execute("""
                    UPDATE inventory_levels
                    SET current_stock = MAX(0, current_stock - ?),
                        last_updated = CURRENT_TIMESTAMP
                    WHERE sku_id = ?;
                    """, (clean_r["quantity"], clean_r["sku_id"]))

                    # Check new stock level
                    cursor.execute("SELECT current_stock FROM inventory_levels WHERE sku_id = ?;", (clean_r["sku_id"],))
                    new_stock_row = cursor.fetchone()
                    new_stock = new_stock_row[0] if new_stock_row else 0

                    if new_stock <= 10:
                        alerts.append({
                            "type": "STOCK_CRITICAL",
                            "sku_id": clean_r["sku_id"],
                            "product_name": clean_r["product_name"],
                            "remaining_stock": new_stock,
                            "message": f"Stock depleted to {new_stock} units for {clean_r['product_name']}!"
                        })

                except Exception as e:
                    print(f"[Realtime Ingestion Error] {e}")

            conn.commit()

        return {
            "ingested_count": len(cleaned_records),
            "records": cleaned_records,
            "alerts": alerts
        }

    def generate_simulated_realtime_bill(self):
        """
        Simulates a live hypermarket customer checkout bill at the cash counter right now.
        """
        sku_keys = list(self.catalog_cache.keys())
        if not sku_keys:
            return None

        tx_id = f"TXN-LIVE-{random.randint(100000, 999999)}"
        cust_id = f"CUST-{random.randint(1000, 1450)}"
        now_ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # 1 to 4 items in this customer's basket
        basket_len = random.choice([1, 2, 2, 3, 4])
        selected_skus = random.sample(sku_keys, basket_len)

        raw_items = []
        for sku in selected_skus:
            meta = self.catalog_cache[sku]
            qty = random.choice([1, 1, 2, 3])
            raw_items.append({
                "transaction_id": tx_id,
                "timestamp": now_ts,
                "customer_id": cust_id,
                "sku_id": sku,
                "product_name": meta["product_name"],
                "category": meta["category"],
                "quantity": qty,
                "unit_price": meta["selling_price"],
                "total_amount": round(qty * meta["selling_price"], 2),
                "payment_method": random.choice(["UPI / QR", "Credit/Debit Card", "DMart Wallet", "Cash"])
            })

        return self.ingest_realtime_records(raw_items)
