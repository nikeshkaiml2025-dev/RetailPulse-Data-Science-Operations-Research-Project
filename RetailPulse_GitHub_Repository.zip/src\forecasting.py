import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from statsmodels.tsa.holtwinters import ExponentialSmoothing

class DemandForecaster:
    """
    Time-Series Demand Forecasting using Holt-Winters Exponential Smoothing
    and Seasonal Decomposition.
    """
    def __init__(self, tx_df):
        self.tx_df = tx_df

    def forecast_demand(self, target_type="store", target_val=None, forecast_days=7):
        """
        target_type: 'store', 'category', or 'sku'
        target_val: category name or sku_id (if target_type is not 'store')
        """
        if self.tx_df is None or self.tx_df.empty:
            return {"history": [], "forecast": [], "metrics": {}}

        df = self.tx_df.copy()
        if target_type == "category" and target_val:
            df = df[df["category"] == target_val]
        elif target_type == "sku" and target_val:
            df = df[df["sku_id"] == target_val]

        if df.empty:
            return {"history": [], "forecast": [], "metrics": {}}

        # Aggregate daily demand
        daily_series = df.groupby("date_str")["quantity"].sum().reset_index()
        daily_series["date"] = pd.to_datetime(daily_series["date_str"])
        daily_series = daily_series.sort_values("date").set_index("date")

        # Fill missing dates with 0
        full_idx = pd.date_range(start=daily_series.index.min(), end=daily_series.index.max(), freq="D")
        daily_series = daily_series.reindex(full_idx, fill_value=0)
        y = daily_series["quantity"].astype(float)

        n_obs = len(y)
        forecast_dates = [y.index.max() + timedelta(days=i) for i in range(1, forecast_days + 1)]
        forecast_date_strs = [d.strftime("%Y-%m-%d") for d in forecast_dates]

        # Fit Holt-Winters Exponential Smoothing
        try:
            if n_obs >= 14: # At least 2 weeks of daily data for weekly seasonality
                model = ExponentialSmoothing(
                    y,
                    trend="add",
                    seasonal="add",
                    seasonal_periods=7,
                    initialization_method="estimated"
                ).fit(optimized=True)
                y_pred = model.forecast(forecast_days)
                residuals = y - model.fittedvalues
                std_resid = float(np.std(residuals)) if len(residuals) > 0 else 5.0
            elif n_obs >= 7:
                model = ExponentialSmoothing(
                    y,
                    trend="add",
                    seasonal=None,
                    initialization_method="estimated"
                ).fit(optimized=True)
                y_pred = model.forecast(forecast_days)
                residuals = y - model.fittedvalues
                std_resid = float(np.std(residuals)) if len(residuals) > 0 else 5.0
            else:
                # Naive moving average
                mean_val = float(y.mean())
                y_pred = pd.Series([mean_val] * forecast_days, index=forecast_dates)
                std_resid = float(y.std()) if len(y) > 1 else 3.0

        except Exception as e:
            # Fallback simple smoothing
            mean_val = float(y.tail(7).mean()) if n_obs >= 7 else float(y.mean())
            y_pred = pd.Series([mean_val] * forecast_days, index=forecast_dates)
            std_resid = 5.0

        # Post-process forecast: quantities must be non-negative integers
        forecast_vals = [max(0, int(round(val))) for val in y_pred.values]

        # Prediction Intervals (90% Confidence Band: Z = 1.645)
        lower_bounds = [max(0, int(round(val - 1.645 * std_resid))) for val in forecast_vals]
        upper_bounds = [int(round(val + 1.645 * std_resid)) for val in forecast_vals]

        history_data = [
            {"date": dt.strftime("%Y-%m-%d"), "actual_units": int(qty)}
            for dt, qty in zip(daily_series.index, y.values)
        ]

        forecast_data = [
            {
                "date": d_str,
                "day_name": dt.strftime("%a"),
                "forecast_units": f_val,
                "lower_bound": l_b,
                "upper_bound": u_b
            }
            for d_str, dt, f_val, l_b, u_b in zip(forecast_date_strs, forecast_dates, forecast_vals, lower_bounds, upper_bounds)
        ]

        # Evaluation metrics
        avg_hist = float(y.mean())
        total_forecast = sum(forecast_vals)

        return {
            "target": target_val if target_val else "Store Total",
            "history": history_data,
            "forecast": forecast_data,
            "metrics": {
                "historical_mean_daily": round(avg_hist, 1),
                "residual_std_error": round(std_resid, 2),
                "total_projected_demand": total_forecast,
                "forecast_horizon_days": forecast_days
            }
        }
