import pandas as pd
import numpy as np

class TrendingAnalyticsEngine:
    """
    Pure statistical engine for detecting trending products, sales velocity,
    surges, and deadstock items from POS history.
    """
    def __init__(self, tx_df):
        self.tx_df = tx_df

    def compute_product_trends(self, target_date=None):
        """
        Calculates sales velocity, 7-day baseline comparison, rate of change (RoC),
        Z-score surge index, and trending classification for each SKU.
        """
        if self.tx_df is None or self.tx_df.empty:
            return pd.DataFrame()

        df = self.tx_df.copy()
        all_dates = sorted(df["date_str"].unique())
        if not all_dates:
            return pd.DataFrame()

        latest_date = target_date if (target_date and target_date in all_dates) else all_dates[-1]

        # Aggregate daily sales per SKU
        daily_sku = df.groupby(["date_str", "sku_id", "product_name", "category"]).agg(
            daily_qty=("quantity", "sum"),
            daily_rev=("total_amount", "sum")
        ).reset_index()

        # Unique SKUs
        sku_meta = df[["sku_id", "product_name", "category", "unit_price"]].drop_duplicates(subset=["sku_id"])

        # History up to latest_date
        history_df = daily_sku[daily_sku["date_str"] <= latest_date]
        today_df = daily_sku[daily_sku["date_str"] == latest_date]

        results = []
        for _, sku_row in sku_meta.iterrows():
            sku = sku_row["sku_id"]
            pname = sku_row["product_name"]
            cat = sku_row["category"]
            price = sku_row["unit_price"]

            sku_hist = history_df[history_df["sku_id"] == sku].sort_values("date_str")
            sku_today = today_df[today_df["sku_id"] == sku]

            today_units = int(sku_today["daily_qty"].sum()) if not sku_today.empty else 0
            today_rev = round(float(sku_today["daily_rev"].sum()), 2) if not sku_today.empty else 0.0

            # Calculate Historical Stats (last 14 days)
            recent_hist = sku_hist.tail(14)
            if len(recent_hist) > 1:
                hist_series = recent_hist["daily_qty"]
                mean_qty = float(hist_series.mean())
                std_qty = float(hist_series.std(ddof=1))
                if np.isnan(std_qty) or std_qty == 0:
                    std_qty = 1.0

                # 7-day Moving Average
                ma7 = float(recent_hist.tail(7)["daily_qty"].mean())
                if ma7 > 0:
                    roc = round(((today_units - ma7) / ma7) * 100.0, 1)
                else:
                    roc = 100.0 if today_units > 0 else 0.0

                # Z-Score of today's demand surge
                z_score = round((today_units - mean_qty) / std_qty, 2)
            else:
                mean_qty = float(today_units)
                std_qty = 1.0
                ma7 = float(today_units)
                roc = 0.0
                z_score = 0.0

            # Total Historical Volume & Revenue
            total_historical_units = int(sku_hist["daily_qty"].sum())
            total_historical_rev = round(float(sku_hist["daily_rev"].sum()), 2)

            # Categorize SKU Status
            if today_units >= ma7 * 1.25 and today_units >= 10:
                trend_status = "🔥 Rising Star (Surge)"
                badge = "surge"
            elif today_units >= ma7 * 0.9 and today_units >= 15:
                trend_status = "⭐ Steady High Velocity"
                badge = "high"
            elif today_units > 0:
                trend_status = "📊 Moderate Velocity"
                badge = "normal"
            else:
                trend_status = "❄️ Zero Movement (Deadstock Risk)"
                badge = "deadstock"

            results.append({
                "sku_id": sku,
                "product_name": pname,
                "category": cat,
                "unit_price": price,
                "today_units_sold": today_units,
                "today_revenue": today_rev,
                "avg_daily_demand": round(mean_qty, 1),
                "ma7_demand": round(ma7, 1),
                "growth_rate_pct": roc,
                "z_surge_score": z_score,
                "trend_status": trend_status,
                "badge": badge,
                "total_historical_units": total_historical_units,
                "total_historical_revenue": total_historical_rev
            })

        res_df = pd.DataFrame(results)
        # Sort by today's units sold descending, then growth rate
        res_df = res_df.sort_values(by=["today_units_sold", "growth_rate_pct"], ascending=[False, False]).reset_index(drop=True)
        return res_df

    def get_category_breakdown(self, target_date=None):
        """
        Category-level revenue and volume breakdown with Pareto percentage.
        """
        df = self.tx_df
        if target_date:
            df = df[df["date_str"] == str(target_date)]

        if df.empty:
            return pd.DataFrame()

        cat_summary = df.groupby("category").agg(
            total_revenue=("total_amount", "sum"),
            total_units=("quantity", "sum"),
            total_transactions=("transaction_id", "nunique")
        ).reset_index()

        cat_summary["total_revenue"] = cat_summary["total_revenue"].round(2)
        total_rev_all = cat_summary["total_revenue"].sum()
        cat_summary["revenue_share_pct"] = round((cat_summary["total_revenue"] / total_rev_all) * 100, 2)
        cat_summary = cat_summary.sort_values("total_revenue", ascending=False).reset_index(drop=True)
        
        # Cumulative share for Pareto
        cat_summary["cumulative_share_pct"] = cat_summary["revenue_share_pct"].cumsum().round(2)
        return cat_summary
