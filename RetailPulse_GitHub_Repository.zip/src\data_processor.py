import pandas as pd
import numpy as np
from datetime import datetime

class POSDataProcessor:
    """
    Ingests, validates, cleans, and standardizes retail POS billing transactions.
    """
    REQUIRED_COLUMNS = [
        "transaction_id", "timestamp", "sku_id", "product_name", 
        "category", "quantity", "unit_price", "total_amount"
    ]

    def __init__(self, tx_df=None, catalog_df=None, inventory_df=None):
        self.tx_df = None
        self.catalog_df = catalog_df
        self.inventory_df = inventory_df
        if tx_df is not None:
            self.load_transactions(tx_df)

    def load_transactions(self, data):
        """
        Accepts DataFrame or file path (CSV / Excel).
        """
        if isinstance(data, str):
            if data.endswith(".csv"):
                df = pd.read_csv(data)
            elif data.endswith((".xls", ".xlsx")):
                df = pd.read_excel(data)
            else:
                raise ValueError("Unsupported file format. Please upload CSV or Excel.")
        elif isinstance(data, pd.DataFrame):
            df = data.copy()
        else:
            raise TypeError("Data must be a filepath string or pandas DataFrame.")

        # Validate Schema
        missing = [col for col in self.REQUIRED_COLUMNS if col not in df.columns]
        if missing:
            # Check for common aliases
            rename_map = {
                "bill_no": "transaction_id",
                "invoice_id": "transaction_id",
                "item_code": "sku_id",
                "item_name": "product_name",
                "qty": "quantity",
                "price": "unit_price",
                "amount": "total_amount",
                "dept": "category",
                "department": "category",
                "date": "timestamp",
                "time": "timestamp",
                "datetime": "timestamp"
            }
            df = df.rename(columns=rename_map)
            missing = [col for col in self.REQUIRED_COLUMNS if col not in df.columns]
            if missing:
                raise ValueError(f"Missing required columns in POS dataset: {missing}")

        # Type conversion & cleaning
        df["timestamp"] = pd.to_datetime(df["timestamp"])
        df["quantity"] = pd.to_numeric(df["quantity"], errors="coerce").fillna(1).astype(int)
        df["unit_price"] = pd.to_numeric(df["unit_price"], errors="coerce").fillna(0.0)
        df["total_amount"] = pd.to_numeric(df["total_amount"], errors="coerce").fillna(
            df["quantity"] * df["unit_price"]
        )

        # Filter out corrupted non-positive quantities
        df = df[df["quantity"] > 0].copy()

        # Feature Extraction for Temporal Analysis
        df["date"] = df["timestamp"].dt.date
        df["date_str"] = df["timestamp"].dt.strftime("%Y-%m-%d")
        df["hour"] = df["timestamp"].dt.hour
        df["day_name"] = df["timestamp"].dt.day_name()
        df["day_of_week"] = df["timestamp"].dt.dayofweek # 0=Mon, 6=Sun
        df["is_weekend"] = df["day_of_week"].isin([5, 6]).astype(int)

        if "customer_id" not in df.columns:
            df["customer_id"] = "GUEST"

        self.tx_df = df.sort_values("timestamp").reset_index(drop=True)
        return self.tx_df

    def get_date_range(self):
        if self.tx_df is None or self.tx_df.empty:
            return None, None
        return self.tx_df["date_str"].min(), self.tx_df["date_str"].max()

    def get_kpis(self, target_date=None):
        """
        Calculates store KPIs: Gross Revenue, Total Units Sold, Order Count, AOV, Basket Size.
        If target_date is provided (YYYY-MM-DD), computes for that specific day (worker daily audit mode).
        """
        if self.tx_df is None or self.tx_df.empty:
            return {}

        df = self.tx_df
        if target_date:
            df = df[df["date_str"] == str(target_date)]

        if df.empty:
            return {
                "target_date": target_date or "All Time",
                "total_revenue": 0.0,
                "total_units": 0,
                "total_orders": 0,
                "aov": 0.0,
                "avg_basket_size": 0.0,
                "unique_skus_sold": 0
            }

        total_rev = float(df["total_amount"].sum())
        total_units = int(df["quantity"].sum())
        total_orders = int(df["transaction_id"].nunique())
        aov = round(total_rev / total_orders, 2) if total_orders > 0 else 0.0
        avg_basket_size = round(total_units / total_orders, 2) if total_orders > 0 else 0.0
        unique_skus = int(df["sku_id"].nunique())

        return {
            "target_date": target_date or "All History",
            "total_revenue": round(total_rev, 2),
            "total_units": total_units,
            "total_orders": total_orders,
            "aov": aov,
            "avg_basket_size": avg_basket_size,
            "unique_skus_sold": unique_skus
        }
