// RetailPulse Frontend Application Controller (SQL Backend + Real-Time Preprocessing)
document.addEventListener("DOMContentLoaded", () => {
    // State
    let currentDate = null;
    let availableDates = [];
    let inventoryData = [];
    let trendingData = [];
    let chartInstances = {};
    let autoStreamInterval = null;

    // DOM Elements
    const targetDateSelect = document.getElementById("targetDateSelect");
    const kpiRevenue = document.getElementById("kpiRevenue");
    const kpiUnits = document.getElementById("kpiUnits");
    const kpiOrders = document.getElementById("kpiOrders");
    const kpiAOV = document.getElementById("kpiAOV");
    const kpiAvgBasket = document.getElementById("kpiAvgBasket");
    const kpiUniqueSkus = document.getElementById("kpiUniqueSkus");
    const kpiCriticalRestock = document.getElementById("kpiCriticalRestock");

    const dbRowCount = document.getElementById("dbRowCount");
    const dbSizeKb = document.getElementById("dbSizeKb");
    const dbTotalTx = document.getElementById("dbTotalTx");
    const dbTotalProd = document.getElementById("dbTotalProd");
    const dbTotalDays = document.getElementById("dbTotalDays");
    const dbLifetimeRev = document.getElementById("dbLifetimeRev");
    const dbLatestTs = document.getElementById("dbLatestTs");

    const btnSimulateBill = document.getElementById("btnSimulateBill");
    const btnAutoStream = document.getElementById("btnAutoStream");
    const liveTickerBar = document.getElementById("liveTickerBar");
    const tickerMessage = document.getElementById("tickerMessage");
    const tickerTime = document.getElementById("tickerTime");

    const restockTableBody = document.getElementById("restockTableBody");
    const urgencyFilter = document.getElementById("urgencyFilter");
    const btnExportPO = document.getElementById("btnExportPO");

    const trendingTableBody = document.getElementById("trendingTableBody");
    const skuSearchInput = document.getElementById("skuSearchInput");

    const serviceLevelSlider = document.getElementById("serviceLevelSlider");
    const serviceLevelVal = document.getElementById("serviceLevelVal");
    const abcXyzTableBody = document.getElementById("abcXyzTableBody");

    const minLiftSelect = document.getElementById("minLiftSelect");
    const marketBasketTableBody = document.getElementById("marketBasketTableBody");
    const crossSellCards = document.getElementById("crossSellCards");

    const forecastTypeSelect = document.getElementById("forecastTypeSelect");
    const forecastValSelect = document.getElementById("forecastValSelect");
    const fHistMean = document.getElementById("fHistMean");
    const fProjectedTotal = document.getElementById("fProjectedTotal");
    const fResidualErr = document.getElementById("fResidualErr");

    const rfmClusterCards = document.getElementById("rfmClusterCards");
    const rfmSilScore = document.getElementById("rfmSilScore");
    const rfmSampleTableBody = document.getElementById("rfmSampleTableBody");

    const staffingTableBody = document.getElementById("staffingTableBody");

    // Modal elements
    const uploadModal = document.getElementById("uploadModal");
    const btnUploadModal = document.getElementById("btnUploadModal");
    const btnCloseModal = document.getElementById("btnCloseModal");
    const btnCancelModal = document.getElementById("btnCancelModal");
    const btnSubmitUpload = document.getElementById("btnSubmitUpload");
    const fileInput = document.getElementById("fileInput");
    const dropZone = document.getElementById("dropZone");
    const uploadStatus = document.getElementById("uploadStatus");
    const btnReloadSample = document.getElementById("btnReloadSample");

    let selectedUploadFile = null;

    // ----------------- TAB NAVIGATION -----------------
    const tabBtns = document.querySelectorAll(".tab-btn");
    const tabPanes = document.querySelectorAll(".tab-pane");

    tabBtns.forEach(btn => {
        btn.addEventListener("click", () => {
            tabBtns.forEach(b => b.classList.remove("active"));
            tabPanes.forEach(p => p.classList.remove("active"));

            btn.classList.add("active");
            const targetId = btn.dataset.tab;
            document.getElementById(targetId).classList.add("active");

            if (targetId === "tab-trending") renderTrendingCharts();
            if (targetId === "tab-forecasting") loadForecastData();
            if (targetId === "tab-rfm") loadRfmData();
            if (targetId === "tab-staffing") loadStaffingData();
        });
    });

    // ----------------- DATA FETCHING -----------------
    async function fetchOverview(silent = false) {
        try {
            const url = currentDate ? `/api/overview?date=${currentDate}` : `/api/overview`;
            const res = await fetch(url);
            const data = await res.json();

            if (data.status === "success") {
                currentDate = data.selected_date;
                availableDates = data.all_dates || [];

                if (!silent) {
                    targetDateSelect.innerHTML = "";
                    availableDates.slice().reverse().forEach(dt => {
                        const opt = document.createElement("option");
                        opt.value = dt;
                        opt.textContent = dt === availableDates[availableDates.length - 1] ? `${dt} (Today's Live Bill)` : dt;
                        if (dt === currentDate) opt.selected = true;
                        targetDateSelect.appendChild(opt);
                    });

                    if (data.categories) {
                        forecastValSelect.innerHTML = "";
                        data.categories.forEach(cat => {
                            const opt = document.createElement("option");
                            opt.value = cat;
                            opt.textContent = cat;
                            forecastValSelect.appendChild(opt);
                        });
                    }
                }

                // Render KPIs
                const kpis = data.kpis;
                kpiRevenue.textContent = `₹${kpis.total_revenue.toLocaleString('en-IN')}`;
                kpiUnits.textContent = kpis.total_units.toLocaleString('en-IN');
                kpiOrders.textContent = kpis.total_orders.toLocaleString('en-IN');
                kpiAOV.textContent = `₹${kpis.aov.toFixed(2)}`;
                kpiAvgBasket.textContent = kpis.avg_basket_size.toFixed(1);
                kpiUniqueSkus.textContent = kpis.unique_skus_sold;
                kpiCriticalRestock.textContent = data.critical_restock_count;

                // Update Database Stats
                if (data.db_stats) {
                    const dbs = data.db_stats;
                    dbRowCount.textContent = dbs.total_transactions.toLocaleString('en-IN');
                    dbSizeKb.textContent = dbs.db_size_kb;
                    if (dbTotalTx) dbTotalTx.textContent = dbs.total_transactions.toLocaleString('en-IN');
                    if (dbTotalProd) dbTotalProd.textContent = dbs.total_products;
                    if (dbTotalDays) dbTotalDays.textContent = dbs.days_recorded;
                    if (dbLifetimeRev) dbLifetimeRev.textContent = `₹${dbs.lifetime_revenue_inr.toLocaleString('en-IN')}`;
                    if (dbLatestTs) dbLatestTs.textContent = dbs.latest_transaction_timestamp;
                }

                // Refresh active tabs
                loadRestockData();
                loadTrendingData();
            }
        } catch (err) {
            console.error("Error loading overview:", err);
        }
    }

    // ----------------- REAL-TIME POS BILL SIMULATOR -----------------
    async function triggerSimulatedBill() {
        try {
            const res = await fetch("/api/realtime/simulate-bill", { method: "POST" });
            const data = await res.json();

            if (data.status === "success") {
                const resDetails = data.ingestion_result;
                const itemsStr = resDetails.records.map(r => `${r.quantity}x ${r.product_name}`).join(", ");
                const billId = resDetails.records[0] ? resDetails.records[0].transaction_id : "TXN";

                // Show Live Ticker Feed
                liveTickerBar.classList.remove("hidden");
                tickerMessage.innerHTML = `⚡ Ingested <strong>${billId}</strong>: ${itemsStr} (Stored in SQLite & inventory stock updated)`;
                tickerTime.textContent = new Date().toLocaleTimeString();

                // Refresh dashboard
                fetchOverview(true);
            }
        } catch (err) {
            console.error("Realtime simulation error:", err);
        }
    }

    btnSimulateBill.addEventListener("click", triggerSimulatedBill);

    btnAutoStream.addEventListener("click", () => {
        if (autoStreamInterval) {
            clearInterval(autoStreamInterval);
            autoStreamInterval = null;
            btnAutoStream.textContent = "▶️ Auto Stream (2s)";
            btnAutoStream.classList.remove("active");
        } else {
            autoStreamInterval = setInterval(triggerSimulatedBill, 2000);
            btnAutoStream.textContent = "⏸️ Stop Streaming";
            btnAutoStream.classList.add("active");
            triggerSimulatedBill();
        }
    });

    // ----------------- TAB 1: RESTOCK & PO -----------------
    async function loadRestockData() {
        try {
            const sLevel = serviceLevelSlider.value;
            const url = `/api/inventory-restock?date=${currentDate || ''}&service_level=${sLevel}`;
            const res = await fetch(url);
            const data = await res.json();

            if (data.status === "success") {
                inventoryData = data.inventory_table;
                renderRestockTable();
                renderAbcXyzTable();
            }
        } catch (err) {
            console.error("Error loading restock:", err);
        }
    }

    function renderRestockTable() {
        const filter = urgencyFilter.value;
        restockTableBody.innerHTML = "";

        const filtered = inventoryData.filter(item => {
            if (filter === "ALL") return true;
            if (filter === "CRITICAL") return item.urgency_badge === "critical" || item.urgency_badge === "warning";
            if (filter === "HEALTHY") return item.urgency_badge === "healthy";
            if (filter === "OVERSTOCKED") return item.urgency_badge === "overstocked";
            return true;
        });

        if (filtered.length === 0) {
            restockTableBody.innerHTML = `<tr><td colspan="12" class="text-center">No inventory records matching selected filter.</td></tr>`;
            return;
        }

        filtered.forEach(item => {
            const tr = document.createElement("tr");
            tr.innerHTML = `
                <td><span class="badge badge-${item.urgency_badge}">${item.stock_urgency}</span></td>
                <td><strong>${item.sku_id}</strong><br><small class="text-muted">${item.product_name}</small></td>
                <td>${item.category}</td>
                <td><strong>${item.current_stock}</strong></td>
                <td>${item.avg_daily_demand}</td>
                <td>${item.safety_stock}</td>
                <td>${item.reorder_point_rop}</td>
                <td><strong class="${item.runway_days < 2 ? 'text-danger' : ''}">${item.runway_days} days</strong></td>
                <td><strong class="${item.suggested_order_qty > 0 ? 'text-danger' : ''}">${item.suggested_order_qty}</strong></td>
                <td>₹${item.unit_cost.toFixed(2)}</td>
                <td>₹${item.estimated_po_cost.toLocaleString('en-IN')}</td>
                <td><small>${item.supplier}</small></td>
            `;
            restockTableBody.appendChild(tr);
        });
    }

    btnExportPO.addEventListener("click", () => {
        const sLevel = serviceLevelSlider.value;
        window.location.href = `/api/export-po?date=${currentDate || ''}&service_level=${sLevel}`;
    });

    urgencyFilter.addEventListener("change", renderRestockTable);

    // ----------------- TAB 2: TRENDING & VELOCITY -----------------
    async function loadTrendingData() {
        try {
            const url = `/api/trending?date=${currentDate || ''}`;
            const res = await fetch(url);
            const data = await res.json();

            if (data.status === "success") {
                trendingData = data.trending_products;
                renderTrendingTable(trendingData);
                renderTrendingCharts(data);
            }
        } catch (err) {
            console.error("Error loading trending:", err);
        }
    }

    function renderTrendingTable(items) {
        trendingTableBody.innerHTML = "";
        if (!items || items.length === 0) {
            trendingTableBody.innerHTML = `<tr><td colspan="10" class="text-center">No trending data found.</td></tr>`;
            return;
        }

        items.forEach(p => {
            const tr = document.createElement("tr");
            tr.innerHTML = `
                <td><span class="badge badge-${p.badge}">${p.trend_status}</span></td>
                <td><code>${p.sku_id}</code></td>
                <td><strong>${p.product_name}</strong></td>
                <td>${p.category}</td>
                <td><strong>${p.today_units_sold}</strong></td>
                <td>₹${p.today_revenue.toLocaleString('en-IN')}</td>
                <td>${p.ma7_demand}</td>
                <td><strong class="${p.growth_rate_pct >= 0 ? 'text-success' : 'text-danger'}">${p.growth_rate_pct > 0 ? '+' : ''}${p.growth_rate_pct}%</strong></td>
                <td>${p.z_surge_score > 0 ? '+' : ''}${p.z_surge_score}</td>
                <td>${p.total_historical_units.toLocaleString('en-IN')}</td>
            `;
            trendingTableBody.appendChild(tr);
        });
    }

    skuSearchInput.addEventListener("input", (e) => {
        const query = e.target.value.toLowerCase();
        const filtered = trendingData.filter(p => 
            p.product_name.toLowerCase().includes(query) ||
            p.category.toLowerCase().includes(query) ||
            p.sku_id.toLowerCase().includes(query)
        );
        renderTrendingTable(filtered);
    });

    function renderTrendingCharts(data) {
        if (!trendingData || trendingData.length === 0) return;

        const top10 = trendingData.slice(0, 10);
        const barLabels = top10.map(p => p.product_name.length > 20 ? p.product_name.substring(0, 20) + "..." : p.product_name);
        const barToday = top10.map(p => p.today_units_sold);
        const barMA7 = top10.map(p => p.ma7_demand);

        if (chartInstances.trendingBar) chartInstances.trendingBar.destroy();
        const ctxBar = document.getElementById("trendingBarChart").getContext("2d");
        chartInstances.trendingBar = new Chart(ctxBar, {
            type: "bar",
            data: {
                labels: barLabels,
                datasets: [
                    { label: "Today's Sold Units", data: barToday, backgroundColor: "#0284c7", borderRadius: 4 },
                    { label: "7-Day Avg Baseline", data: barMA7, backgroundColor: "#94a3b8", borderRadius: 4 }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: "top" } },
                scales: { y: { beginAtZero: true, title: { display: true, text: "Units Sold" } } }
            }
        });

        if (data && data.category_breakdown) {
            const catLabels = data.category_breakdown.map(c => c.category);
            const catRevs = data.category_breakdown.map(c => c.total_revenue);

            if (chartInstances.categoryDonut) chartInstances.categoryDonut.destroy();
            const ctxDonut = document.getElementById("categoryDonutChart").getContext("2d");
            chartInstances.categoryDonut = new Chart(ctxDonut, {
                type: "doughnut",
                data: {
                    labels: catLabels,
                    datasets: [{
                        data: catRevs,
                        backgroundColor: ["#0284c7", "#10b981", "#f59e0b", "#8b5cf6", "#ec4899", "#14b8a6", "#64748b"]
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { position: "right" } }
                }
            });
        }
    }

    // ----------------- TAB 3: INVENTORY CALCULUS & ABC-XYZ -----------------
    serviceLevelSlider.addEventListener("input", (e) => {
        const val = parseFloat(e.target.value);
        const z = val >= 0.99 ? 2.33 : (val >= 0.95 ? 1.645 : 1.28);
        serviceLevelVal.textContent = `${Math.round(val * 100)}% (Z=${z})`;
        loadRestockData();
    });

    function renderAbcXyzTable() {
        abcXyzTableBody.innerHTML = "";
        if (!inventoryData || inventoryData.length === 0) return;

        inventoryData.forEach(item => {
            const tr = document.createElement("tr");
            tr.innerHTML = `
                <td><code>${item.sku_id}</code></td>
                <td><strong>${item.product_name}</strong></td>
                <td>${item.category}</td>
                <td><span class="badge badge-segment">${item.abc_class}</span></td>
                <td>${item.cv_score}</td>
                <td>${item.xyz_class}</td>
                <td><strong>${item.abc_xyz_segment}</strong></td>
                <td>${item.economic_order_qty_eoq} units</td>
                <td>${item.margin_pct}%</td>
            `;
            abcXyzTableBody.appendChild(tr);
        });
    }

    // ----------------- TAB 4: MARKET BASKET -----------------
    async function loadMarketBasketData() {
        try {
            const minLift = minLiftSelect.value;
            const url = `/api/market-basket?min_lift=${minLift}`;
            const res = await fetch(url);
            const data = await res.json();

            if (data.status === "success") {
                renderMarketBasket(data);
            }
        } catch (err) {
            console.error("Error loading market basket:", err);
        }
    }

    function renderMarketBasket(data) {
        crossSellCards.innerHTML = "";
        const topSells = data.top_cross_sells || [];

        if (topSells.length === 0) {
            crossSellCards.innerHTML = `<p class="text-muted">No high-confidence association pairs above current threshold.</p>`;
        } else {
            topSells.forEach(cs => {
                const card = document.createElement("div");
                card.className = "cross-sell-card";
                card.innerHTML = `
                    <div class="cs-header">
                        <span>Affinity Lift: <strong>${cs.lift}x</strong></span>
                        <span>Confidence: <strong>${cs.confidence_pct}%</strong></span>
                    </div>
                    <div class="cs-items">
                        ${cs.antecedent} <span class="cs-arrow">➔</span> ${cs.consequent}
                    </div>
                    <div class="cs-action">${cs.action}</div>
                `;
                crossSellCards.appendChild(card);
            });
        }

        marketBasketTableBody.innerHTML = "";
        const rules = data.association_rules || [];
        if (rules.length === 0) {
            marketBasketTableBody.innerHTML = `<tr><td colspan="6" class="text-center">No rules found.</td></tr>`;
            return;
        }

        rules.forEach(r => {
            const tr = document.createElement("tr");
            tr.innerHTML = `
                <td><strong>${r.antecedent_str}</strong></td>
                <td><strong>${r.consequent_str}</strong></td>
                <td>${r.support}%</td>
                <td>${r.confidence}%</td>
                <td><strong class="text-primary">${r.lift}x</strong></td>
                <td><small>${r.planogram_action}</small></td>
            `;
            marketBasketTableBody.appendChild(tr);
        });
    }

    minLiftSelect.addEventListener("change", loadMarketBasketData);

    // ----------------- TAB 5: DEMAND FORECASTING -----------------
    async function loadForecastData() {
        try {
            const targetType = forecastTypeSelect.value;
            const targetVal = targetType === "category" ? forecastValSelect.value : null;

            const url = `/api/forecast?target_type=${targetType}&target_val=${encodeURIComponent(targetVal || '')}&days=7`;
            const res = await fetch(url);
            const data = await res.json();

            if (data.status === "success" && data.forecast_data) {
                renderForecastChart(data.forecast_data);
            }
        } catch (err) {
            console.error("Error loading forecast:", err);
        }
    }

    forecastTypeSelect.addEventListener("change", () => {
        if (forecastTypeSelect.value === "category") {
            forecastValSelect.classList.remove("hidden");
        } else {
            forecastValSelect.classList.add("hidden");
        }
        loadForecastData();
    });

    forecastValSelect.addEventListener("change", loadForecastData);

    function renderForecastChart(fData) {
        const hist = fData.history || [];
        const forecast = fData.forecast || [];
        const metrics = fData.metrics || {};

        fHistMean.textContent = `${metrics.historical_mean_daily || 0} units`;
        fProjectedTotal.textContent = `${metrics.total_projected_demand || 0} units`;
        fResidualErr.textContent = `±${metrics.residual_std_error || 0}`;

        const allDates = [...hist.map(h => h.date), ...forecast.map(f => f.date)];
        const histVals = [...hist.map(h => h.actual_units), ...new Array(forecast.length).fill(null)];
        
        const lastHistVal = hist.length > 0 ? hist[hist.length - 1].actual_units : null;
        const forecastVals = [
            ...new Array(Math.max(0, hist.length - 1)).fill(null),
            lastHistVal,
            ...forecast.map(f => f.forecast_units)
        ];

        const upperVals = [
            ...new Array(Math.max(0, hist.length - 1)).fill(null),
            lastHistVal,
            ...forecast.map(f => f.upper_bound)
        ];

        const lowerVals = [
            ...new Array(Math.max(0, hist.length - 1)).fill(null),
            lastHistVal,
            ...forecast.map(f => f.lower_bound)
        ];

        if (chartInstances.forecastLine) chartInstances.forecastLine.destroy();
        const ctxForecast = document.getElementById("forecastLineChart").getContext("2d");
        chartInstances.forecastLine = new Chart(ctxForecast, {
            type: "line",
            data: {
                labels: allDates,
                datasets: [
                    {
                        label: "Historical POS Sales",
                        data: histVals,
                        borderColor: "#0284c7",
                        backgroundColor: "#0284c7",
                        borderWidth: 2,
                        pointRadius: 3,
                        tension: 0.2
                    },
                    {
                        label: "Holt-Winters 7-Day Forecast",
                        data: forecastVals,
                        borderColor: "#10b981",
                        backgroundColor: "#10b981",
                        borderWidth: 2.5,
                        borderDash: [5, 5],
                        pointRadius: 4,
                        tension: 0.2
                    },
                    {
                        label: "90% Confidence Upper Band",
                        data: upperVals,
                        borderColor: "rgba(16, 185, 129, 0.25)",
                        backgroundColor: "rgba(16, 185, 129, 0.1)",
                        fill: "+1",
                        borderWidth: 1,
                        pointRadius: 0,
                        tension: 0.2
                    },
                    {
                        label: "90% Confidence Lower Band",
                        data: lowerVals,
                        borderColor: "rgba(16, 185, 129, 0.25)",
                        fill: false,
                        borderWidth: 1,
                        pointRadius: 0,
                        tension: 0.2
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: "top" },
                    tooltip: { mode: "index", intersect: false }
                },
                scales: {
                    y: { beginAtZero: true, title: { display: true, text: "Daily Demand Units" } }
                }
            }
        });
    }

    // ----------------- TAB 6: CUSTOMER RFM -----------------
    async function loadRfmData() {
        try {
            const res = await fetch("/api/rfm-clusters?n_clusters=4");
            const data = await res.json();

            if (data.status === "success") {
                renderRfm(data);
            }
        } catch (err) {
            console.error("Error loading RFM:", err);
        }
    }

    function renderRfm(data) {
        const meta = data.cluster_meta || {};
        rfmSilScore.textContent = meta.silhouette_score || "0.00";

        rfmClusterCards.innerHTML = "";
        (meta.clusters || []).forEach(c => {
            const card = document.createElement("div");
            card.className = "rfm-card";
            card.innerHTML = `
                <div class="rfm-header">
                    <span class="rfm-name">${c.name}</span>
                    <span class="rfm-badge">${c.pct_of_base}% of shoppers</span>
                </div>
                <div class="rfm-stats-list">
                    <div>👥 Shoppers: <strong>${c.customer_count}</strong></div>
                    <div>📅 Avg Recency: <strong>${c.avg_recency_days} days</strong></div>
                    <div>🛒 Avg Visits: <strong>${c.avg_frequency_trips} trips</strong></div>
                    <div>💰 Avg Spend: <strong>₹${c.avg_monetary_inr.toLocaleString('en-IN')}</strong></div>
                </div>
                <div class="rfm-strategy">🎯 <strong>Strategy:</strong> ${c.strategy}</div>
            `;
            rfmClusterCards.appendChild(card);
        });

        const sample = data.customer_sample || [];
        const scatterData = sample.map(cust => ({
            x: cust.frequency,
            y: cust.monetary,
            label: cust.customer_id
        }));

        if (chartInstances.rfmScatter) chartInstances.rfmScatter.destroy();
        const ctxScatter = document.getElementById("rfmScatterChart").getContext("2d");
        chartInstances.rfmScatter = new Chart(ctxScatter, {
            type: "scatter",
            data: {
                datasets: [{
                    label: "Customers (Spend vs Frequency)",
                    data: scatterData,
                    backgroundColor: "#6366f1",
                    pointRadius: 5
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: { title: { display: true, text: "Frequency (Total Store Trips)" } },
                    y: { title: { display: true, text: "Monetary Spend (₹)" } }
                }
            }
        });

        rfmSampleTableBody.innerHTML = "";
        sample.slice(0, 10).forEach(s => {
            const tr = document.createElement("tr");
            tr.innerHTML = `
                <td><code>${s.customer_id}</code></td>
                <td>${s.recency} days ago</td>
                <td>${s.frequency} visits</td>
                <td>₹${s.monetary.toLocaleString('en-IN')}</td>
                <td><span class="badge badge-segment">${s.segment_name}</span></td>
            `;
            rfmSampleTableBody.appendChild(tr);
        });
    }

    // ----------------- TAB 7: QUEUE & STAFFING -----------------
    async function loadStaffingData() {
        try {
            const res = await fetch("/api/staffing");
            const data = await res.json();

            if (data.status === "success" && data.staffing_data) {
                renderStaffing(data.staffing_data);
            }
        } catch (err) {
            console.error("Error loading staffing:", err);
        }
    }

    function renderStaffing(staffing) {
        const stats = staffing.hourly_stats || [];

        const labels = stats.map(s => `${s.hour}:00`);
        const arrivals = stats.map(s => s.avg_transactions);
        const cashiers = stats.map(s => s.recommended_cashiers);

        if (chartInstances.staffingBar) chartInstances.staffingBar.destroy();
        const ctxStaffing = document.getElementById("staffingBarChart").getContext("2d");
        chartInstances.staffingBar = new Chart(ctxStaffing, {
            type: "bar",
            data: {
                labels: labels,
                datasets: [
                    { label: "Avg Customer Arrivals / hr", data: arrivals, backgroundColor: "#0284c7", borderRadius: 4 },
                    { label: "Recommended Active Cashier Desks", data: cashiers, type: "line", borderColor: "#ef4444", backgroundColor: "#ef4444", borderWidth: 2, pointRadius: 4 }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: "top" } },
                scales: { y: { beginAtZero: true, title: { display: true, text: "Volume / Desks" } } }
            }
        });

        staffingTableBody.innerHTML = "";
        stats.filter(s => s.hour >= 7 && s.hour <= 23).forEach(s => {
            const tr = document.createElement("tr");
            tr.innerHTML = `
                <td><strong>${s.time_window}</strong></td>
                <td>${s.avg_transactions} bills/hr</td>
                <td>${s.peak_transactions} bills</td>
                <td><span class="badge ${s.rush_badge === 'rush_high' ? 'badge-critical' : 'badge-healthy'}">${s.rush_level}</span></td>
                <td><strong style="font-size: 1.1rem; color: #0284c7;">${s.recommended_cashiers} Desks</strong></td>
                <td>${s.recommended_cashiers >= 5 ? '⚡ Open express checkout lane & deploy backup packager.' : 'Standard single cashier operations.'}</td>
            `;
            staffingTableBody.appendChild(tr);
        });
    }

    // ----------------- AUDIT DATE CHANGE -----------------
    targetDateSelect.addEventListener("change", (e) => {
        currentDate = e.target.value;
        fetchOverview();
    });

    // ----------------- UPLOAD MODAL & FILE HANDLING -----------------
    btnUploadModal.addEventListener("click", () => {
        uploadModal.classList.remove("hidden");
        uploadStatus.className = "status-msg hidden";
        selectedUploadFile = null;
        fileInput.value = "";
        btnSubmitUpload.disabled = true;
    });

    [btnCloseModal, btnCancelModal].forEach(btn => {
        btn.addEventListener("click", () => uploadModal.classList.add("hidden"));
    });

    fileInput.addEventListener("change", (e) => {
        if (e.target.files.length > 0) {
            selectedUploadFile = e.target.files[0];
            btnSubmitUpload.disabled = false;
            uploadStatus.textContent = `Selected: ${selectedUploadFile.name} (${Math.round(selectedUploadFile.size / 1024)} KB)`;
            uploadStatus.className = "status-msg status-success";
            uploadStatus.classList.remove("hidden");
        }
    });

    btnSubmitUpload.addEventListener("click", async () => {
        if (!selectedUploadFile) return;

        const formData = new FormData();
        formData.append("file", selectedUploadFile);

        btnSubmitUpload.disabled = true;
        btnSubmitUpload.textContent = "Preprocessing & Ingesting...";

        try {
            const res = await fetch("/api/upload-pos", {
                method: "POST",
                body: formData
            });
            const data = await res.json();

            if (data.status === "success") {
                uploadStatus.textContent = data.message;
                uploadStatus.className = "status-msg status-success";
                setTimeout(() => {
                    uploadModal.classList.add("hidden");
                    fetchOverview();
                }, 1200);
            } else {
                uploadStatus.textContent = `Error: ${data.message}`;
                uploadStatus.className = "status-msg status-error";
            }
        } catch (err) {
            uploadStatus.textContent = `Upload failed: ${err.message}`;
            uploadStatus.className = "status-msg status-error";
        } finally {
            btnSubmitUpload.disabled = false;
            btnSubmitUpload.textContent = "Preprocess & Ingest to SQL";
        }
    });

    btnReloadSample.addEventListener("click", async () => {
        try {
            await fetch("/api/reload-sample", { method: "POST" });
            fetchOverview();
        } catch (err) {
            console.error("Error reloading sample data:", err);
        }
    });

    // Initial Load
    fetchOverview();
});
