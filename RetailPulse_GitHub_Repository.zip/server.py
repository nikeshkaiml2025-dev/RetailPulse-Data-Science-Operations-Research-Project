import os
import io
import pandas as pd
from flask import Flask, render_template, request, jsonify, send_file, Response

from src.database import RetailDatabase
from src.realtime_pipeline import RealtimeDataPipeline
from src.data_processor import POSDataProcessor
from src.trending_engine import TrendingAnalyticsEngine
from src.inventory_math import InventoryOptimizationEngine
from src.market_basket import MarketBasketMiner
from src.forecasting import DemandForecaster
from src.rfm_analytics import CustomerRFMAnalyzer
from src.queue_staffing import QueueStaffingOptimizer

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
EXPORTS_DIR = os.path.join(BASE_DIR, "exports")
os.makedirs(EXPORTS_DIR, exist_ok=True)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 32 * 1024 * 1024

class RetailSystemState:
    def __init__(self):
        self.db = RetailDatabase(os.path.join(DATA_DIR, "retail_store.db"))
        self.realtime_pipeline = None
        self.processor = None
        self.trending_engine = None
        self.inventory_engine = None
        self.market_basket_miner = None
        self.forecaster = None
        self.rfm_analyzer = None
        self.staffing_optimizer = None
        self.selected_target_date = None

    def initialize(self):
        # 1. Seed database from CSV if empty
        cat_csv = os.path.join(DATA_DIR, "product_catalog.csv")
        inv_csv = os.path.join(DATA_DIR, "inventory_levels.csv")
        tx_csv = os.path.join(DATA_DIR, "sample_dmart_transactions.csv")
        
        self.db.seed_from_csv(cat_csv, inv_csv, tx_csv)
        self.realtime_pipeline = RealtimeDataPipeline(self.db)
        self.reload_from_db()

    def reload_from_db(self):
        df_tx = self.db.get_all_transactions_df()
        df_inv = self.db.get_inventory_df()
        df_cat = self.db.get_catalog_df()

        self.processor = POSDataProcessor(df_tx, df_cat, df_inv)
        clean_df = self.processor.tx_df

        self.trending_engine = TrendingAnalyticsEngine(clean_df)
        self.inventory_engine = InventoryOptimizationEngine(clean_df, df_inv)
        self.market_basket_miner = MarketBasketMiner(clean_df)
        self.forecaster = DemandForecaster(clean_df)
        self.rfm_analyzer = CustomerRFMAnalyzer(clean_df)
        self.staffing_optimizer = QueueStaffingOptimizer(clean_df)

        all_dates = sorted(clean_df["date_str"].unique()) if not clean_df.empty else []
        self.selected_target_date = all_dates[-1] if all_dates else None

state = RetailSystemState()
state.initialize()

# ----------------- HTML WEB INTERFACE -----------------
@app.route("/")
def index():
    return render_template("index.html")

# ----------------- SQL & REALTIME ENDPOINTS -----------------
@app.route("/api/db/stats", methods=["GET"])
def get_db_stats():
    stats = state.db.get_database_stats()
    return jsonify({"status": "success", "db_stats": stats})

@app.route("/api/realtime/simulate-bill", methods=["POST"])
def simulate_realtime_bill():
    result = state.realtime_pipeline.generate_simulated_realtime_bill()
    # Reload in-memory analytics engine with fresh SQL data
    state.reload_from_db()
    
    kpis = state.processor.get_kpis(state.selected_target_date)
    return jsonify({
        "status": "success",
        "ingestion_result": result,
        "updated_kpis": kpis
    })

# ----------------- CORE DATA SCIENCE APIs -----------------
@app.route("/api/overview", methods=["GET"])
def get_overview():
    target_date = request.args.get("date", state.selected_target_date)
    kpis = state.processor.get_kpis(target_date)
    min_date, max_date = state.processor.get_date_range()
    
    inv_params = state.inventory_engine.compute_inventory_parameters(target_date=target_date)
    critical_count = int((inv_params["urgency_badge"] == "critical").sum()) if not inv_params.empty else 0
    warning_count = int((inv_params["urgency_badge"] == "warning").sum()) if not inv_params.empty else 0

    all_dates = sorted(state.processor.tx_df["date_str"].unique()) if state.processor.tx_df is not None else []
    categories = sorted(state.processor.tx_df["category"].unique()) if state.processor.tx_df is not None else []
    db_stats = state.db.get_database_stats()

    return jsonify({
        "status": "success",
        "kpis": kpis,
        "date_range": {"min": min_date, "max": max_date},
        "all_dates": all_dates,
        "selected_date": target_date,
        "categories": categories,
        "critical_restock_count": critical_count,
        "warning_restock_count": warning_count,
        "db_stats": db_stats
    })

@app.route("/api/trending", methods=["GET"])
def get_trending():
    target_date = request.args.get("date", state.selected_target_date)
    trends_df = state.trending_engine.compute_product_trends(target_date=target_date)
    cat_df = state.trending_engine.get_category_breakdown(target_date=target_date)

    return jsonify({
        "status": "success",
        "trending_products": trends_df.to_dict(orient="records"),
        "category_breakdown": cat_df.to_dict(orient="records")
    })

@app.route("/api/inventory-restock", methods=["GET"])
def get_inventory_restock():
    target_date = request.args.get("date", state.selected_target_date)
    service_level = float(request.args.get("service_level", 0.95))
    inv_df = state.inventory_engine.compute_inventory_parameters(service_level=service_level, target_date=target_date)
    
    po_items = inv_df[inv_df["needs_reorder"] == True]
    total_po_cost = round(float(po_items["estimated_po_cost"].sum()), 2)
    total_order_units = int(po_items["suggested_order_qty"].sum())
    total_items_to_order = len(po_items)

    return jsonify({
        "status": "success",
        "inventory_table": inv_df.to_dict(orient="records"),
        "po_summary": {
            "total_items_to_order": total_items_to_order,
            "total_order_units": total_order_units,
            "total_po_cost_inr": total_po_cost
        }
    })

@app.route("/api/export-po", methods=["GET"])
def export_purchase_order():
    target_date = request.args.get("date", state.selected_target_date)
    service_level = float(request.args.get("service_level", 0.95))
    inv_df = state.inventory_engine.compute_inventory_parameters(service_level=service_level, target_date=target_date)
    po_df = state.inventory_engine.generate_purchase_order_df(inv_df)

    if po_df.empty:
        return jsonify({"status": "error", "message": "No items currently require restocking."}), 400

    output = io.StringIO()
    po_df.to_csv(output, index=False)
    output.seek(0)

    filename = f"DMart_Restock_PurchaseOrder_{target_date or 'latest'}.csv"
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment;filename={filename}"}
    )

@app.route("/api/market-basket", methods=["GET"])
def get_market_basket():
    min_support = float(request.args.get("min_support", 0.015))
    min_confidence = float(request.args.get("min_confidence", 0.25))
    
    _, rules = state.market_basket_miner.run_association_mining(
        min_support=min_support, 
        min_confidence=min_confidence
    )
    
    top_cross_sells = state.market_basket_miner.get_top_cross_sells(top_n=10)

    return jsonify({
        "status": "success",
        "association_rules": rules.to_dict(orient="records") if not rules.empty else [],
        "top_cross_sells": top_cross_sells
    })

@app.route("/api/forecast", methods=["GET"])
def get_forecast():
    target_type = request.args.get("target_type", "store")
    target_val = request.args.get("target_val", None)
    days = int(request.args.get("days", 7))
    
    forecast_result = state.forecaster.forecast_demand(
        target_type=target_type,
        target_val=target_val,
        forecast_days=days
    )

    return jsonify({
        "status": "success",
        "forecast_data": forecast_result
    })

@app.route("/api/rfm-clusters", methods=["GET"])
def get_rfm():
    n_clusters = int(request.args.get("n_clusters", 4))
    rfm_df, cluster_meta = state.rfm_analyzer.compute_rfm_clusters(n_clusters=n_clusters)
    sample_customers = rfm_df.head(150).to_dict(orient="records") if not rfm_df.empty else []

    return jsonify({
        "status": "success",
        "cluster_meta": cluster_meta,
        "customer_sample": sample_customers,
        "total_segmented_customers": len(rfm_df)
    })

@app.route("/api/staffing", methods=["GET"])
def get_staffing():
    staffing_data = state.staffing_optimizer.analyze_peak_hours()
    return jsonify({
        "status": "success",
        "staffing_data": staffing_data
    })

@app.route("/api/upload-pos", methods=["POST"])
def upload_pos():
    if "file" not in request.files:
        return jsonify({"status": "error", "message": "No file uploaded."}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"status": "error", "message": "No selected file."}), 400

    try:
        if file.filename.endswith(".csv"):
            df = pd.read_csv(file)
        elif file.filename.endswith((".xls", ".xlsx")):
            df = pd.read_excel(file)
        else:
            return jsonify({"status": "error", "message": "Please upload a .csv or .xlsx file."}), 400

        # Preprocess each record and stream into SQLite
        records = df.to_dict(orient="records")
        ingest_res = state.realtime_pipeline.ingest_realtime_records(records)
        state.reload_from_db()
        kpis = state.processor.get_kpis(state.selected_target_date)

        return jsonify({
            "status": "success",
            "message": f"Successfully preprocessed and inserted {ingest_res['ingested_count']} transactions into SQLite backend!",
            "kpis": kpis,
            "latest_date": state.selected_target_date
        })

    except Exception as e:
        return jsonify({"status": "error", "message": f"Data preprocessing error: {str(e)}"}), 500

@app.route("/api/reload-sample", methods=["POST"])
def reload_sample():
    # Remove existing sqlite database and re-seed
    db_file = os.path.join(DATA_DIR, "retail_store.db")
    if os.path.exists(db_file):
        try:
            os.remove(db_file)
        except Exception:
            pass
    state.initialize()
    return jsonify({"status": "success", "message": "SQLite database re-seeded from baseline CSV!"})

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5001))
    print("\n=======================================================")
    print(" [RetailPulse] Pure Data Science & SQL Platform is LIVE!")
    print(f" Access URL: http://localhost:{port} or http://127.0.0.1:{port}")
    print("=======================================================\n")
    try:
        app.run(host="0.0.0.0", port=port, debug=False)
    except Exception as e:
        alt_port = 8080
        print(f"Port {port} busy, switching to http://localhost:{alt_port}")
        app.run(host="0.0.0.0", port=alt_port, debug=False)
