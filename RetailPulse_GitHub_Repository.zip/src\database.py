import os
import sqlite3
import pandas as pd
from datetime import datetime

class RetailDatabase:
    """
    Production-grade SQLite relational database backend for RetailPulse.
    Maintains indexed tables for products, inventory, transactions, customers, and restock purchase orders.
    """
    def __init__(self, db_path=None):
        if db_path is None:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            data_dir = os.path.join(base_dir, "data")
            os.makedirs(data_dir, exist_ok=True)
            self.db_path = os.path.join(data_dir, "retail_store.db")
        else:
            self.db_path = db_path

        self.init_schema()

    def get_connection(self):
        conn = sqlite3.connect(self.db_path, timeout=30.0, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        # Enable WAL mode for high concurrency
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA foreign_keys=ON;")
        return conn

    def init_schema(self):
        """
        Creates normalized relational schema with indexes.
        """
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # 1. Product Master Table
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS product_catalog (
                sku_id TEXT PRIMARY KEY,
                product_name TEXT NOT NULL,
                category TEXT NOT NULL,
                cost_price REAL NOT NULL,
                selling_price REAL NOT NULL,
                supplier TEXT NOT NULL,
                lead_time_days INTEGER NOT NULL DEFAULT 3,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            """)

            # 2. Inventory Master Table
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS inventory_levels (
                sku_id TEXT PRIMARY KEY,
                current_stock INTEGER NOT NULL,
                unit_cost REAL NOT NULL,
                lead_time_days INTEGER NOT NULL,
                order_fixed_cost REAL NOT NULL DEFAULT 350.0,
                annual_holding_cost REAL NOT NULL,
                min_order_batch INTEGER NOT NULL DEFAULT 10,
                supplier TEXT NOT NULL,
                last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (sku_id) REFERENCES product_catalog(sku_id)
            );
            """)

            # 3. Transactions Table (Indexed for high-speed time-series and SKU lookups)
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS pos_transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                transaction_id TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                date_str TEXT NOT NULL,
                hour INTEGER NOT NULL,
                day_name TEXT NOT NULL,
                is_weekend INTEGER NOT NULL,
                customer_id TEXT NOT NULL,
                sku_id TEXT NOT NULL,
                product_name TEXT NOT NULL,
                category TEXT NOT NULL,
                quantity INTEGER NOT NULL,
                unit_price REAL NOT NULL,
                total_amount REAL NOT NULL,
                payment_method TEXT NOT NULL,
                ingested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (sku_id) REFERENCES product_catalog(sku_id)
            );
            """)

            # Indexes for lightning fast queries
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_tx_date ON pos_transactions(date_str);")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_tx_sku ON pos_transactions(sku_id);")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_tx_cust ON pos_transactions(customer_id);")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_tx_timestamp ON pos_transactions(timestamp);")

            # 4. Restock Purchase Orders Audit Table
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS purchase_orders (
                order_id TEXT PRIMARY KEY,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                target_date TEXT NOT NULL,
                total_skus INTEGER NOT NULL,
                total_units INTEGER NOT NULL,
                total_cost REAL NOT NULL,
                status TEXT NOT NULL DEFAULT 'GENERATED'
            );
            """)

            conn.commit()

    def seed_from_csv(self, catalog_csv, inventory_csv, tx_csv):
        """
        Seeds SQL database from CSV files if empty.
        """
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # Check if already populated
            cursor.execute("SELECT COUNT(*) FROM product_catalog;")
            if cursor.fetchone()[0] == 0 and os.path.exists(catalog_csv):
                df_cat = pd.read_csv(catalog_csv)
                df_cat.to_sql("product_catalog", conn, if_exists="append", index=False)
                print(f"[SQL DB] Seeded {len(df_cat)} products into product_catalog table.")

            cursor.execute("SELECT COUNT(*) FROM inventory_levels;")
            if cursor.fetchone()[0] == 0 and os.path.exists(inventory_csv):
                df_inv = pd.read_csv(inventory_csv)
                # Keep matching columns
                cols = ["sku_id", "current_stock", "unit_cost", "lead_time_days", "order_fixed_cost", "annual_holding_cost", "min_order_batch", "supplier"]
                df_inv[cols].to_sql("inventory_levels", conn, if_exists="append", index=False)
                print(f"[SQL DB] Seeded {len(df_inv)} inventory records into inventory_levels table.")

            cursor.execute("SELECT COUNT(*) FROM pos_transactions;")
            if cursor.fetchone()[0] == 0 and os.path.exists(tx_csv):
                df_tx = pd.read_csv(tx_csv)
                df_tx["timestamp"] = pd.to_datetime(df_tx["timestamp"])
                df_tx["date_str"] = df_tx["timestamp"].dt.strftime("%Y-%m-%d")
                df_tx["hour"] = df_tx["timestamp"].dt.hour
                df_tx["day_name"] = df_tx["timestamp"].dt.day_name()
                df_tx["is_weekend"] = df_tx["timestamp"].dt.dayofweek.isin([5, 6]).astype(int)
                df_tx["timestamp"] = df_tx["timestamp"].dt.strftime("%Y-%m-%d %H:%M:%S")

                cols = [
                    "transaction_id", "timestamp", "date_str", "hour", "day_name",
                    "is_weekend", "customer_id", "sku_id", "product_name", "category",
                    "quantity", "unit_price", "total_amount", "payment_method"
                ]
                df_tx[cols].to_sql("pos_transactions", conn, if_exists="append", index=False)
                print(f"[SQL DB] Seeded {len(df_tx)} billing transactions into pos_transactions table.")

            conn.commit()

    def get_all_transactions_df(self):
        """
        Fetches all transactions from SQL database into a DataFrame.
        """
        with self.get_connection() as conn:
            query = "SELECT * FROM pos_transactions ORDER BY timestamp ASC;"
            df = pd.read_sql_query(query, conn)
            df["timestamp"] = pd.to_datetime(df["timestamp"])
            df["day_of_week"] = df["timestamp"].dt.dayofweek
            return df

    def get_inventory_df(self):
        """
        Fetches current inventory master from SQL database.
        """
        with self.get_connection() as conn:
            query = """
            SELECT i.sku_id, p.product_name, p.category, i.current_stock, i.unit_cost,
                   i.lead_time_days, i.order_fixed_cost, i.annual_holding_cost,
                   i.min_order_batch, i.supplier
            FROM inventory_levels i
            JOIN product_catalog p ON i.sku_id = p.sku_id;
            """
            return pd.read_sql_query(query, conn)

    def get_catalog_df(self):
        with self.get_connection() as conn:
            return pd.read_sql_query("SELECT * FROM product_catalog;", conn)

    def get_database_stats(self):
        """
        Returns live SQL table row counts and database metrics.
        """
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM pos_transactions;")
            tx_count = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(DISTINCT date_str) FROM pos_transactions;")
            days_count = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM product_catalog;")
            prod_count = cursor.fetchone()[0]

            cursor.execute("SELECT SUM(total_amount) FROM pos_transactions;")
            lifetime_rev = cursor.fetchone()[0] or 0.0

            cursor.execute("SELECT timestamp FROM pos_transactions ORDER BY id DESC LIMIT 1;")
            latest_tx = cursor.fetchone()
            latest_ts = latest_tx[0] if latest_tx else "N/A"

            size_bytes = os.path.getsize(self.db_path) if os.path.exists(self.db_path) else 0

            return {
                "db_type": "SQLite3 (WAL Mode)",
                "db_file": os.path.basename(self.db_path),
                "db_size_kb": round(size_bytes / 1024, 1),
                "total_transactions": tx_count,
                "total_products": prod_count,
                "days_recorded": days_count,
                "lifetime_revenue_inr": round(float(lifetime_rev), 2),
                "latest_transaction_timestamp": latest_ts
            }
