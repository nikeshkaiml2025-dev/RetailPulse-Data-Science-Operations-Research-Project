import pandas as pd
import numpy as np
from mlxtend.frequent_patterns import apriori, association_rules

class MarketBasketMiner:
    """
    Market Basket Analysis Engine using Apriori Association Rule Mining.
    Extracts frequent itemsets, calculates Support, Confidence, Lift, Leverage,
    and generates hypermarket shelf planograms and cross-merchandising combos.
    """
    def __init__(self, tx_df):
        self.tx_df = tx_df

    def run_association_mining(self, min_support=0.015, min_lift=1.1, min_confidence=0.25):
        """
        Runs Apriori on POS transaction baskets and computes association metrics.
        """
        if self.tx_df is None or self.tx_df.empty:
            return pd.DataFrame(), pd.DataFrame()

        df = self.tx_df.copy()

        # Build Transaction x Product One-Hot Matrix
        # Filter for products to make readable names
        basket = df.groupby(["transaction_id", "product_name"])["quantity"].sum().unstack().reset_index().fillna(0).set_index("transaction_id")
        
        # Convert quantities to boolean (True or False)
        basket_encoded = (basket > 0).astype(bool)

        # Drop transactions with only 1 item if we want basket associations
        basket_encoded = basket_encoded[basket_encoded.sum(axis=1) > 1]
        
        if basket_encoded.empty:
            return pd.DataFrame(), pd.DataFrame()

        # Apriori frequent itemsets
        try:
            frequent_itemsets = apriori(basket_encoded, min_support=min_support, use_colnames=True)
        except Exception as e:
            print(f"Apriori warning: {e}")
            return pd.DataFrame(), pd.DataFrame()

        if frequent_itemsets.empty:
            # Fallback with slightly lower support if dataset is sparse
            frequent_itemsets = apriori(basket_encoded, min_support=0.008, use_colnames=True)
            if frequent_itemsets.empty:
                return pd.DataFrame(), pd.DataFrame()

        # Association Rules
        try:
            rules = association_rules(frequent_itemsets, metric="lift", min_threshold=min_lift)
        except Exception as e:
            print(f"Rules error: {e}")
            return frequent_itemsets, pd.DataFrame()

        if rules.empty:
            return frequent_itemsets, pd.DataFrame()

        # Filter by confidence
        rules = rules[rules["confidence"] >= min_confidence].copy()

        # Format Antecedents and Consequents strings and drop frozenset columns
        rules["antecedents_list"] = rules["antecedents"].apply(list)
        rules["consequents_list"] = rules["consequents"].apply(list)
        rules["antecedent_str"] = rules["antecedents"].apply(lambda x: ", ".join(list(x)))
        rules["consequent_str"] = rules["consequents"].apply(lambda x: ", ".join(list(x)))
        
        # Drop raw frozensets to ensure clean JSON serialization
        rules = rules.drop(columns=["antecedents", "consequents"])

        # Format clean columns
        rules["support"] = (rules["support"] * 100).round(2)
        rules["confidence"] = (rules["confidence"] * 100).round(2)
        rules["lift"] = rules["lift"].round(2)
        rules["leverage"] = (rules["leverage"] * 100).round(3)
        rules["conviction"] = rules["conviction"].apply(lambda x: round(x, 2) if not np.isinf(x) else 99.9)

        # Generate Actionable Shelf Planogram / Cross-Selling Recommendation
        def get_planogram_action(row):
            lift = row["lift"]
            conf = row["confidence"]
            ant = row["antecedent_str"]
            con = row["consequent_str"]

            if lift >= 2.5:
                return f"🔥 High-Affinity Bundle: Create end-cap promotional combo of [{ant}] + [{con}]."
            elif lift >= 1.8:
                return f"🛒 Aisle Co-Location: Position [{con}] directly next to [{ant}] to maximize impulse buys."
            elif conf >= 50.0:
                return f"⚡ Cashier Suggestion: Prompt checkout staff to offer [{con}] when customer buys [{ant}]."
            else:
                return f"📦 Shelf Proximity: Maintain nearby shelf placement for [{ant}] and [{con}]."

        rules["planogram_action"] = rules.apply(get_planogram_action, axis=1)

        # Sort by Lift descending
        rules = rules.sort_values(by=["lift", "confidence"], ascending=[False, False]).reset_index(drop=True)
        return frequent_itemsets, rules

    def get_top_cross_sells(self, top_n=8):
        """
        Returns clean, formatted list of top cross-selling pairs for the UI.
        """
        _, rules = self.run_association_mining()
        if rules.empty:
            return []

        clean_rules = []
        for _, r in rules.head(top_n).iterrows():
            clean_rules.append({
                "antecedent": r["antecedent_str"],
                "consequent": r["consequent_str"],
                "support_pct": r["support"],
                "confidence_pct": r["confidence"],
                "lift": r["lift"],
                "action": r["planogram_action"]
            })
        return clean_rules
