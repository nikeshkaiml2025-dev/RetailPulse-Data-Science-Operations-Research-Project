import os
import unittest
import pandas as pd
import numpy as np

from src.database import RetailDatabase
from src.realtime_pipeline import RealtimeDataPipeline
from src.data_processor import POSDataProcessor
from src.trending_engine import TrendingAnalyticsEngine
from src.inventory_math import InventoryOptimizationEngine
from src.market_basket import MarketBasketMiner
from src.forecasting import DemandForecaster
from src.rfm_analytics import CustomerRFMAnalyzer
from src.queue_staffing import QueueStaffingOptimizer
from server import app, state

class TestRetailDataSciencePipeline(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.base_dir = os.path.dirname(os.path.abspath(__file__))
        cls.data_dir = os.path.join(cls.base_dir, "data")
        cls.test_db_path = os.path.join(cls.data_dir, "test_retail.db")

        if os.path.exists(cls.test_db_path):
            os.remove(cls.test_db_path)

        cls.db = RetailDatabase(cls.test_db_path)
        cls.cat_csv = os.path.join(cls.data_dir, "product_catalog.csv")
        cls.inv_csv = os.path.join(cls.data_dir, "inventory_levels.csv")
        cls.tx_csv = os.path.join(cls.data_dir, "sample_dmart_transactions.csv")

        cls.db.seed_from_csv(cls.cat_csv, cls.inv_csv, cls.tx_csv)
        cls.pipeline = RealtimeDataPipeline(cls.db)
        cls.client = app.test_client()

    @classmethod
    def tearDownClass(cls):
        if os.path.exists(cls.test_db_path):
            try:
                os.remove(cls.test_db_path)
            except Exception:
                pass

    def test_01_sql_database_stats(self):
        stats = self.db.get_database_stats()
        self.assertGreater(stats["total_transactions"], 1000)
        self.assertGreater(stats["total_products"], 20)
        self.assertGreater(stats["lifetime_revenue_inr"], 100000)
        print("[PASS] SQLite DB test: Rows =", stats["total_transactions"], "Size =", stats["db_size_kb"], "KB")

    def test_02_realtime_preprocessing_and_deduction(self):
        # Check initial stock of DRY-101
        inv_before = self.db.get_inventory_df()
        stock_before = int(inv_before[inv_before["sku_id"] == "DRY-101"]["current_stock"].iloc[0])

        # Ingest simulated bill with 2 units of DRY-101
        raw_bill = {
            "transaction_id": "TXN-UNITTEST-001",
            "timestamp": "2026-08-18 12:00:00",
            "customer_id": "CUST-TEST",
            "sku_id": "DRY-101",
            "quantity": 2,
            "payment_method": "UPI / QR"
        }
        res = self.pipeline.ingest_realtime_records(raw_bill)
        self.assertEqual(res["ingested_count"], 1)

        # Check stock after deduction
        inv_after = self.db.get_inventory_df()
        stock_after = int(inv_after[inv_after["sku_id"] == "DRY-101"]["current_stock"].iloc[0])
        self.assertEqual(stock_after, max(0, stock_before - 2))
        print("[PASS] Realtime Preprocessing & Atomic Stock Deduction test passed: Stock", stock_before, "->", stock_after)

    def test_03_trending_engine(self):
        df_tx = self.db.get_all_transactions_df()
        engine = TrendingAnalyticsEngine(df_tx)
        trends = engine.compute_product_trends()
        self.assertFalse(trends.empty)
        self.assertIn("z_surge_score", trends.columns)
        self.assertIn("trend_status", trends.columns)
        print(f"[PASS] Trending Engine test: Analyzed {len(trends)} SKUs.")

    def test_04_inventory_math(self):
        df_tx = self.db.get_all_transactions_df()
        df_inv = self.db.get_inventory_df()
        inv_engine = InventoryOptimizationEngine(df_tx, df_inv)
        inv_res = inv_engine.compute_inventory_parameters()
        self.assertFalse(inv_res.empty)
        self.assertIn("safety_stock", inv_res.columns)
        self.assertIn("reorder_point_rop", inv_res.columns)
        self.assertIn("economic_order_qty_eoq", inv_res.columns)
        self.assertIn("abc_xyz_segment", inv_res.columns)

        po_df = inv_engine.generate_purchase_order_df(inv_res)
        self.assertFalse(po_df.empty)
        print(f"[PASS] Inventory Math test: Generated PO with {len(po_df)} reorder line items.")

    def test_05_market_basket(self):
        df_tx = self.db.get_all_transactions_df()
        miner = MarketBasketMiner(df_tx)
        itemsets, rules = miner.run_association_mining(min_support=0.01, min_lift=1.1)
        self.assertFalse(rules.empty)
        self.assertIn("lift", rules.columns)
        top_cross = miner.get_top_cross_sells(top_n=5)
        self.assertGreater(len(top_cross), 0)
        print(f"[PASS] Market Basket test: Extracted {len(rules)} association rules. Top rule lift: {rules['lift'].max()}x")

    def test_06_forecasting(self):
        df_tx = self.db.get_all_transactions_df()
        forecaster = DemandForecaster(df_tx)
        res = forecaster.forecast_demand(forecast_days=7)
        self.assertEqual(len(res["forecast"]), 7)
        self.assertGreater(res["metrics"]["total_projected_demand"], 0)
        print(f"[PASS] Forecasting test: 7-day projected demand = {res['metrics']['total_projected_demand']} units.")

    def test_07_rfm_segmentation(self):
        df_tx = self.db.get_all_transactions_df()
        rfm_analyzer = CustomerRFMAnalyzer(df_tx)
        rfm_df, meta = rfm_analyzer.compute_rfm_clusters(n_clusters=4)
        self.assertFalse(rfm_df.empty)
        self.assertIn("cluster", rfm_df.columns)
        self.assertIn("segment_name", rfm_df.columns)
        print(f"[PASS] RFM Segmentation test: Segmented {len(rfm_df)} customers. Silhouette score: {meta['silhouette_score']}")

    def test_08_queue_staffing(self):
        df_tx = self.db.get_all_transactions_df()
        optimizer = QueueStaffingOptimizer(df_tx)
        res = optimizer.analyze_peak_hours()
        self.assertEqual(len(res["hourly_stats"]), 24)
        print("[PASS] Queue Staffing test: Computed 24-hour staffing schedule.")

    def test_09_flask_api_endpoints(self):
        routes = [
            "/api/db/stats",
            "/api/overview",
            "/api/trending",
            "/api/inventory-restock",
            "/api/export-po",
            "/api/market-basket",
            "/api/forecast",
            "/api/rfm-clusters",
            "/api/staffing"
        ]
        for route in routes:
            res = self.client.get(route)
            self.assertEqual(res.status_code, 200, f"Route {route} failed with status {res.status_code}")

        # Test POST /api/realtime/simulate-bill
        res_post = self.client.post("/api/realtime/simulate-bill")
        self.assertEqual(res_post.status_code, 200)
        print("[PASS] Flask REST API tests: All 9 endpoints + Live Bill Simulation responded 200 OK.")

if __name__ == "__main__":
    unittest.main()
