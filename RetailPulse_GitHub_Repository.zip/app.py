# RetailPulse App Entrypoint
from server import app

if __name__ == "__main__":
    import os
    port = int(os.environ.get("PORT", 5001))
    print("\n=======================================================")
    print(" [RetailPulse] Pure Data Science Platform is LIVE!")
    print(f" Access URL: http://localhost:{port} or http://127.0.0.1:{port}")
    print("=======================================================\n")
    try:
        app.run(host="0.0.0.0", port=port, debug=False)
    except Exception as e:
        alt_port = 8080
        print(f"Port {port} busy, switching to http://localhost:{alt_port}")
        app.run(host="0.0.0.0", port=alt_port, debug=False)
