import pandas as pd
import numpy as np

class QueueStaffingOptimizer:
    """
    Analyzes hourly transaction arrival distributions and computes
    optimal cashier counter staffing recommendations.
    """
    def __init__(self, tx_df):
        self.tx_df = tx_df

    def analyze_peak_hours(self, avg_checkout_mins=2.5, target_utilization=0.75):
        """
        Computes hourly checkout traffic density, peak rush flags,
        and recommended active cashier desks per hour.
        """
        if self.tx_df is None or self.tx_df.empty:
            return {"hourly_stats": [], "heatmap": [], "peak_hours": []}

        df = self.tx_df.copy()
        if "day_of_week" not in df.columns:
            df["timestamp"] = pd.to_datetime(df["timestamp"])
            df["day_of_week"] = df["timestamp"].dt.dayofweek
        if "day_name" not in df.columns:
            df["day_name"] = df["timestamp"].dt.day_name()
        
        # Aggregate unique transactions per date and hour
        hourly_tx = df.groupby(["date_str", "hour"])["transaction_id"].nunique().reset_index()

        # Mean and max transaction arrival rate lambda per hour
        hourly_summary = hourly_tx.groupby("hour")["transaction_id"].agg(
            mean_arrivals="mean",
            max_arrivals="max",
            min_arrivals="min"
        ).reset_index()

        # Fill all 24 hours
        all_hours = pd.DataFrame({"hour": range(24)})
        hourly_summary = pd.merge(all_hours, hourly_summary, on="hour", how="left").fillna(0)

        results = []
        for _, r in hourly_summary.iterrows():
            hr = int(r["hour"])
            lam = float(r["mean_arrivals"])
            max_lam = float(r["max_arrivals"])

            # Service rate per cashier desk per hour: mu = 60 / avg_checkout_mins
            mu = 60.0 / avg_checkout_mins # e.g. 24 customers / hr per desk

            # Recommended desks = ceil(lambda / (mu * target_utilization))
            if lam > 0:
                recommended_desks = int(np.ceil(lam / (mu * target_utilization)))
                recommended_desks = max(1, min(recommended_desks, 12)) # Between 1 and 12 desks
            else:
                recommended_desks = 1 if (9 <= hr <= 22) else 0

            # Rush categorization
            if lam >= 15:
                rush_level = "🔥 Heavy Rush Hour"
                rush_badge = "rush_high"
            elif lam >= 8:
                rush_level = "⚡ Moderate Traffic"
                rush_badge = "rush_med"
            elif lam > 0:
                rush_level = "🌱 Normal / Slow"
                rush_badge = "rush_low"
            else:
                rush_level = "🌙 Store Closed / Minimal"
                rush_badge = "rush_closed"

            time_label = f"{hr:02d}:00 - {(hr+1)%24:02d}:00"

            results.append({
                "hour": hr,
                "time_window": time_label,
                "avg_transactions": round(lam, 1),
                "peak_transactions": int(max_lam),
                "recommended_cashiers": recommended_desks,
                "rush_level": rush_level,
                "rush_badge": rush_badge
            })

        # Day of Week x Hour Heatmap data
        dow_hour = df.groupby(["day_of_week", "day_name", "hour"])["transaction_id"].nunique().reset_index()
        dow_pivot = dow_hour.pivot_table(index=["day_of_week", "day_name"], columns="hour", values="transaction_id", aggfunc="mean").fillna(0)
        
        heatmap_data = []
        day_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
        for d_idx, d_name in enumerate(day_order):
            if (d_idx, d_name) in dow_pivot.index:
                row_vals = [round(float(v), 1) for v in dow_pivot.loc[(d_idx, d_name)].values]
            else:
                row_vals = [0.0] * 24
            heatmap_data.append({"day": d_name, "hourly_values": row_vals})

        # Top Peak Hours
        top_peaks = sorted([r for r in results if r["avg_transactions"] > 0], key=lambda x: x["avg_transactions"], reverse=True)[:4]

        return {
            "hourly_stats": results,
            "heatmap": heatmap_data,
            "top_peaks": top_peaks
        }
