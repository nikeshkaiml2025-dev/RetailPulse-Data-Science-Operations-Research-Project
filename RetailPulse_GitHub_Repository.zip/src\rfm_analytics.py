import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

class CustomerRFMAnalyzer:
    """
    Customer Segmentation Engine using RFM (Recency, Frequency, Monetary)
    Feature Engineering and K-Means Clustering.
    """
    def __init__(self, tx_df):
        self.tx_df = tx_df

    def compute_rfm_clusters(self, n_clusters=4):
        """
        Extracts RFM metrics and fits K-Means clustering.
        """
        if self.tx_df is None or self.tx_df.empty:
            return pd.DataFrame(), {}

        df = self.tx_df[self.tx_df["customer_id"] != "GUEST"].copy()
        if df.empty:
            return pd.DataFrame(), {}

        snapshot_date = df["timestamp"].max()

        # Compute RFM table per customer
        rfm = df.groupby("customer_id").agg({
            "timestamp": lambda x: (snapshot_date - x.max()).days, # Recency in days
            "transaction_id": "nunique",                            # Frequency
            "total_amount": "sum"                                   # Monetary
        }).reset_index()

        rfm.columns = ["customer_id", "recency", "frequency", "monetary"]
        rfm["monetary"] = rfm["monetary"].round(2)

        if len(rfm) < n_clusters:
            rfm["cluster"] = 0
            rfm["segment_name"] = "General Shoppers"
            return rfm, {}

        # Log transform to reduce retail monetary skewness
        rfm_transformed = pd.DataFrame()
        rfm_transformed["recency_log"] = np.log1p(rfm["recency"])
        rfm_transformed["frequency_log"] = np.log1p(rfm["frequency"])
        rfm_transformed["monetary_log"] = np.log1p(rfm["monetary"])

        # Standard Scaler
        scaler = StandardScaler()
        rfm_scaled = scaler.fit_transform(rfm_transformed)

        # K-Means
        kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
        rfm["cluster"] = kmeans.fit_predict(rfm_scaled)

        # Evaluate Silhouette Score
        sil_score = round(float(silhouette_score(rfm_scaled, rfm["cluster"])), 3)

        # Profile clusters based on mean metrics
        cluster_summary = rfm.groupby("cluster").agg({
            "recency": "mean",
            "frequency": "mean",
            "monetary": "mean",
            "customer_id": "count"
        }).reset_index()

        # Dynamic cluster naming based on centroid ranking
        # Score = high freq + high monetary - high recency
        cluster_summary["score"] = (
            (cluster_summary["frequency"] / cluster_summary["frequency"].max()) * 0.4 +
            (cluster_summary["monetary"] / cluster_summary["monetary"].max()) * 0.4 -
            (cluster_summary["recency"] / cluster_summary["recency"].max()) * 0.2
        )
        cluster_summary = cluster_summary.sort_values("score", ascending=False).reset_index(drop=True)

        persona_names = [
            ("🏆 Champions / VIP Spenders", "Top spenders with high repeat store visits. Reward with VIP loyalty perks and early festival discounts."),
            ("🌱 Loyal Regulars", "Consistent weekly shoppers. Encourage cross-category exploration via personalized basket vouchers."),
            ("⚠️ At-Risk / Lapsing Customers", "High historical spend but haven't visited recently. Send win-back SMS/WhatsApp deals."),
            ("🛒 Occasional / Value Hunters", "Infrequent, price-conscious shoppers. Offer discount bundles and flash clearance sales.")
        ]

        segment_map = {}
        strategy_map = {}
        for idx, row in cluster_summary.iterrows():
            c_id = int(row["cluster"])
            p_name, p_strat = persona_names[min(idx, len(persona_names) - 1)]
            segment_map[c_id] = p_name
            strategy_map[c_id] = p_strat

        rfm["segment_name"] = rfm["cluster"].map(segment_map)
        rfm["strategy"] = rfm["cluster"].map(strategy_map)

        # Compute cluster cards for UI
        cluster_cards = []
        for c_id in sorted(rfm["cluster"].unique()):
            c_df = rfm[rfm["cluster"] == c_id]
            cluster_cards.append({
                "cluster_id": int(c_id),
                "name": segment_map.get(c_id, f"Segment {c_id}"),
                "strategy": strategy_map.get(c_id, ""),
                "customer_count": int(len(c_df)),
                "pct_of_base": round((len(c_df) / len(rfm)) * 100, 1),
                "avg_recency_days": round(float(c_df["recency"].mean()), 1),
                "avg_frequency_trips": round(float(c_df["frequency"].mean()), 1),
                "avg_monetary_inr": round(float(c_df["monetary"].mean()), 2),
                "total_segment_revenue": round(float(c_df["monetary"].sum()), 2)
            })

        return rfm, {"silhouette_score": sil_score, "clusters": cluster_cards}
